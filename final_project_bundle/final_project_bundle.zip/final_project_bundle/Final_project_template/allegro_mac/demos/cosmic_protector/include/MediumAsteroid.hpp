#ifndef MEDIUMASTEROID_HPP
#define MEDIUMASTEROID_HPP

class MediumAsteroid : public Asteroid
{
public:
   void spawn(void);

   MediumAsteroid();
   ~MediumAsteroid();
};

#endif // MEDIUMASTEROID_HPP

