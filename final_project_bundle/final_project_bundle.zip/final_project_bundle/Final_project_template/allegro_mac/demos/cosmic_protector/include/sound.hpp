#ifndef SOUND_HPP
#define SOUND_HPP

void my_play_sample(int resourceID);

#endif // SOUND_HPP
