#ifndef DEBUG_H
#define DEBUG_H

#include "cosmic_protector.hpp"

void debug_message(const char *, ...);

#endif

